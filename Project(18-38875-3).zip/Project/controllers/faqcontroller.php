<?php
   require_once  'models/db_config.php';
   session_start();
   $h_name="";
   $err_name="";
   $h_id="";
   $err_h_id="";
   $faq="";
   $err_faq="";
   $err_db="";
   $hasError=false;
   
   if(isset($_POST["submit"])){
	   if(empty($_POST["name"])){
		   $hasError=true;
		   $err_name = "Please enter your name.";
	   }
	   else{
		   $h_name=$_POST["name"];
	   }
	   
	   if(empty($_POST["Userid"])){
		   $hasError=true;
		   $err_h_id = "Please enter your id.";
	   }
	   else{
		   $h_id=$_POST["Userid"];
	   }
	   if(empty($_POST["faq"])){
		   $hasError=true;
		   $err_faq = "Please enter your query.";
	   }
	   else{
		   $faq=$_POST["faq"];
	   }
	   if(!$hasError){
		   $rs=insertFaq($h_name, $h_id, $faq);
		   if($rs===true){
			   $_SESSION["loggeduser"] = $h_name;
			   header("Location: menu.php");
		   }
		   else{
			   $err_db=$rs;
		   }
	   }
   }
   
   else if(isset($_POST["home"])){
	   header("Location: controllers/home.php"); 
   }
   
   function insertFaq($h_name, $h_id, $faq){
       $query="insert into faq values (NULL, '$h_name', '$h_id', '$faq')";
       return execute($query);
	   }
	   
   function getFaq(){
	$query = "select * from faq";
	$rs = get($query);
	return $rs;
  }
  
   function getFaqById($h_id){
	$query = "select * from faq where id=$h_id";
	$rs = get($query);
	return $rs;
  }

?>
