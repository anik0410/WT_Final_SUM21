<?php
  session_start();
  include 'models/db_config.php';

  $name="";
  $err_name="";
  $uname="";
  $err_uname="";
  $pass="";
  $err_pass="";
  $err_db="";
  $hasError=false;
  
  if(isset($_POST["register"])){
    if(empty($_POST["name"])){
      $hasError=true;
      $err_name="*Name Required";
    }
    else{
      $name=$_POST["name"];
    }
    if(empty($_POST["uname"])){
      $hasError=true;
      $err_uname="*Username Required";
    }
    else{
      $uname=$_POST["uname"];
    }
    if(empty($_POST["pass"])){
      $hasError=true;
      $err_pass="*Password Required";
    }
    else{
      $pass=$_POST["pass"];
    }
	
	if(!$hasError){
      $rs = insertUser($name,$uname,$pass);
      if($rs === true){
         header("Location: login.php");
      }
      $err_db = $rs;
    }
  }
  else if(isset($_POST["login"])){
    if(empty($_POST["uname"])){
      $hasError=true;
      $err_uname="Username Required";
    }
    else{
      $uname=$_POST["uname"];
    }
    if(empty($_POST["pass"])){
      $hasError=true;
      $err_pass="Password Required";
    }
    else{
      $pass=$_POST["pass"];
    }
	if(!$hasError){
      if(authenticateUser($uname,$pass)){
		  echo '1';
		 $_SESSION["uname"] = $uname;
		setcookie("uname", $uname, time()+120);
		  
        header("Location: menu.php");
      }
      $err_db = "Username and password invalid";
    }
  }
  
  else if(isset($_POST["change"])){

    if(!$hasError){
      $rs = updateUser($_POST["name"],$_POST["uname"],$_POST["pass"],$_POST["id"]);
      if($rs===true){
        session_destroy();
        header("Location: login.php");
      }
	  echo '1';
      $err_db = $rs;
    }
  }
  
  function insertUser($name,$uname,$pass){
    $query = "insert into user values (NULL,'$name','$uname', '$pass')";
    return execute($query);
  }
  
  
  function getUserWithUsername($uname){
      $query = "select * from user where uname = '$uname'";
      $rs = get($query);
      return $rs[0] ;
   }
   
   function updateUser($name,$uname,$pass,$id){
    $query = "update user set name='$name',uname='$uname',pass='$pass' where id=$id";
    return execute($query);
  }



  
  function authenticateUser($uname,$pass){
    $query = "select * from user where uname='$uname' and pass='$pass'";
    $rs = get($query);
    if(count($rs) > 0){
		$_SESSION["id"]=$rs[0]["id"];
      return true;
    }
	echo 'hi';
      return false;
  }

?>