<?php
   require_once  'models/db_config.php';
   $h_name="";
   $err_name="";
   $p_id="";
   $err_p_id="";
   $review="";
   $err_review="";
   $err_db="";
   $hasError=false;
   
      if(isset($_POST["submit"])){
	   if(empty($_POST["name"])){
		   $hasError=true;
		   $err_name = "Please enter your name.";
	   }
	   else{
		   $h_name=$_POST["name"];
	   }
	   
	   if(empty($_POST["Userid"])){
		   $hasError=true;
		   $err_p_id = "Please enter your id.";
	   }
	   else{
		   $p_id=$_POST["Userid"];
	   }
	  
	   
	   
	   if(empty($_POST["review"])){
		   $hasError=true;
		   $err_review = "Please enter your review.";
	   }
	   else{
		   $review=$_POST["review"];
	   }
	   
	   
	   if(!$hasError){
		   $rs=insertReview($h_name, $p_id, $review);
		   if($rs===true){
	
			   header("Location: controllers/home.php");
		   }
		   else{
			   $err_db=$rs;
		   }
	   }
   }
   
   else if(isset($_POST["home"])){
	   header("Location: controllers/home.php"); 
   }
   
      function insertReview($h_name, $p_id, $review){
       $query="insert into rateandreview values (NULL, '$h_name', '$p_id', '$review')";
       return execute($query);
	   }
	   
   function getReview(){
	$query = "select * from rateandreview";
	$rs = get($query);
	return $rs;
  }
?>