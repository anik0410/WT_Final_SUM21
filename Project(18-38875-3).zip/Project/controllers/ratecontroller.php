<?php
  
   require_once  'models/db_config.php';
   $h_name="";
   $err_name="";
   $p_id="";
   $err_h_id="";
   $h_rate="";
   $err_h_rating="";
   $err_db="";
   $hasError=false;
   
      if(isset($_POST["submit"])){
	   if(empty($_POST["name"])){
		   $hasError=true;
		   $err_name = "Please enter your name.";
	   }
	   else{
		   $h_name=$_POST["name"];
	   }
	   
	   if(empty($_POST["Userid"])){
		   $hasError=true;
		   $err_h_id = "Please enter your id.";
	   }
	   else{
		   $p_id=$_POST["Userid"];
	   }
	   
	   
	   if(empty($_POST["h_rate"])){
		   $hasError=true;
		   $err_h_rating = "Please enter your rating.";
	   }
	   else{
		   $h_rate=$_POST["h_rate"];
	   }
	   
	   
	   
	   if(!$hasError){
		   $rs=insertReviewandRating($h_name, 1, $h_rate);
		   if($rs===true){
	
			   header("Location: controllers/home.php");
		   }
		   else{
			   $err_db=$rs;
		   }
	   }
   }
   
   else if(isset($_POST["home"])){
	   header("Location: menu.php"); 
   }
   
      function insertReviewandRating($h_name, $p_id, $h_rate){
       $query="insert into rate values (NULL, '$h_name', '$p_id', '$h_rate')";
       return execute($query);
	   }
	   
   function getReviewandRating(){
	$query = "select * from rate";
	$rs = get($query);
	return $rs;
  }
?>