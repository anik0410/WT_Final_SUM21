<?php
  require_once 'models/db_config.php';
 // session_start();

  $p_type="";
  $err_p_type="";
  $p_location="";
  $err_p_location="";
  $p_price="";
  $err_p_price="";
  $p_img="";
  $err_p_img="";
  $err_db="";
  $hasError=false;

  if(isset($_POST["add_ad"])){
    if(empty($_POST["p_type"])){
      $hasError = true;
      $err_p_type = " Advertiesment Type Required";
    }
    else{
      $p_type = $_POST["p_type"];
    }
    if(empty($_POST["p_location"])){
      $hasError = true;
      $err_p_location = " Property Location Required";
    }
    else{
      $p_location = $_POST["p_location"];
    }
    if(empty($_POST["p_price"])){
      $hasError = true;
      $err_p_price = " Property Price Required";
    }
    else{
      $p_price = $_POST["p_price"];
    }
    
    /*if(empty($_POST["p_img"])){
      $hasError = true;
      $err_p_img = " Image Required";
    }
    else{
      $p_img = $_POST["p_img"];
    }*/

    /*$name = basename($_FILES["p_img"]["name"]);
    $ext = strtolower(pathinfo($name,PATHINFO_EXTENSION));
    $myfilename = uniqid().".$ext";
    $target = "storage/building_pictures/$myfilename";
    $tmp_path = $_FILES["p_img"]["tmp_name"];
    move_uploaded_file($tmp_path,$target);*/

    $fileType = strtolower(pathinfo(basename($_FILES["p_img"]["name"]),PATHINFO_EXTENSION));
		$loc = "storage/building_pictures/".uniqid().".$fileType";
		move_uploaded_file($_FILES["p_img"]["tmp_name"],$loc);
    /*if(empty($_POST["h_id"])){
      $hasError = true;
    }
    else{
      $h_id = $_POST["h_id"];
    }*/
    if(!$hasError){
      $rs = insertAdvertisement($p_type,$p_location,$p_price,$loc,$_POST["id"]);
      if($rs===true){
        //$h_id = $_SESSION["h_id"];
        header("Location: menu.php");
      }
      $err_db = $rs;
	  //var_dump($_POST);

    }

  }
  else if(isset($_POST["edit_advertisement"])){
		if(empty($_POST["p_type"])){
      $hasError = true;
      $err_p_type = " Advertisement Type Required";
    }
    else{
      $p_type = $_POST["p_type"];
    }
		if(empty($_POST["p_location"])){
      $hasError = true;
      $err_p_location = " Property Location Required";
    }
    else{
      $p_location = $_POST["p_location"];
    }
		if(empty($_POST["p_price"])){
      $hasError = true;
      $err_p_price = " Property Price Required";
    }
    else{
      $p_price = $_POST["p_price"];
    }

    if(!$hasError){
      $rs = updateAdvertisement($p_type,$p_location,$p_price,$_POST["p_id"]);
      if($rs===true){
        header("Location: myadvertisements.php");
      }
      $err_db = $rs;
    }
  }
  else if(isset($_POST["delete_add"])){

    if(!$hasError){
      $rs = deleteAdvertisement($_POST["p_type"],$_POST["p_location"],$_POST["p_price"],$_POST["p_id"]);
      if($rs===true){
          header("Location: myadvertisements.php");
      }
      $err_db = $rs;
    }
  }
  else if(isset($_POST["search"])){

    if(!$hasError){
       if(searchAdvertisementLocation($_POST["p_location"])){
         $p_location = $_POST["p_location"];
        header("Location: searchresult.php?p_location=$p_location");
       }

    }
  }



  function insertAdvertisement($p_type,$p_location,$p_price,$p_img,$id){
	  //$h_id = $_SESSION["h_id"];
    $query = "insert into advert values (NULL,'$p_type','$p_location','$p_price','$p_img',$id)";
    return execute($query);
	//echo $h_id;
	//var_dump($_SESSION);
  }
  function getAdvertisements(){
	  $id = $_SESSION["id"];
    $query = "select * from advert where id = '$id'";
    $rs = get($query);
    return $rs;
	//var_dump($rs);
   //echo $h_uname;
   //echo ($_SESSION["h_id"]);

  }
  function getAdvertisement($p_id){
    $query = "select * from advert where p_id = '$p_id'";
    $rs = get($query);
    return $rs[0];
  }
  function updateAdvertisement($p_type,$p_location,$p_price,$p_id){
    $query = "update advert set p_type='$p_type',p_location='$p_location',p_price='$p_price' where p_id=$p_id";
    return execute($query);
  }
  function deleteAdvertisement($p_id){
    $query = "delete from advert where p_id = '$p_id'";
    return execute($query);
  }
  function getUser(){
	$query = "select * from user";
	$rs = get($query);
	return $rs;
  }
  function getUserWithUsername($uname){
	$query = "select * from user where uname = '$uname'";
    $rs = get($query);
    return $rs[0];
  }
  function searchAdvertisementLocation($p_location){
    $query = "select * from advert where p_location = '$p_location'";
    $rs = get($query);
    return $rs;
  }
  function searchAdvertisement($key){
    $query = "select p.p_id,p.p_location,p.p_price from advert p left join user h on p.id=h.id where p.p_location like '%$key%' or h.name like '%$key%' or p.p_price like '%$key%'";
    $rs = get($query);
    return $rs;
    //"select * from properties where p_location like '%$key%'";

  }
?>
