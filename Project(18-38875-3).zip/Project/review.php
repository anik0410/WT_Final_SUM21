<?php 

   include 'userheader.php';
   require_once 'controllers/reviewcontroller.php';
?>
<script src="js/review.js"></script>
<div class="center-login">
  <h1 class="text text-center">Please leave us a rating for the property you sold or rented <?php echo $_SESSION["uname"]; ?></h1> 
  <h5 class="text-danger"><?php echo $err_db; ?></h5>  
  <form action="" method="post" class="form-horizontal form-material">
  <div class="form-group">
     <h4 class="text">Name</h4>
	 <input type="text" name="name" value="<?php echo $h_name; ?>" class="form-control">
	 <span class="text-danger"><?php echo $err_name; ?></span>
  </div>   
  <div class="form-group">
     <h4 class="text">User Id</h4>
	 <input type="text" name="Userid" value="<?php echo $p_id; ?>" class="form-control">
	 <span class="text-danger"><?php echo $err_p_id; ?></span>
  </div>
  <div class="form-group">
     <h4 class="text">Leave you review about the property here</h4>
	 <textarea name="review" value="<?php echo $review; ?>"></textarea>
	 <span class="text-danger"><?php echo $err_review; ?></span>
  </div>
  <div class="form-group">
     <input type="submit" name="submit" value="Submit" class="btn btn-control" class="form-control">
  </div>
  <div class="form-group">
     <input type="submit" name="home" value="Home" class="btn btn-control" class="form-control">
  </div>
  </form></tr>
</div>

<?php include 'userfooter.php' ?>   