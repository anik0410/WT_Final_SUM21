<html>
<head>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<link rel="stylesheet" href="styles1/mystyle.css">
	</head>
	<body>
 <header  class="header">
    <div class="header-index">
			<a class="btn"><b class="text-white name">NAVANA REAL ESTATE LTD</b></a>
			<div class="pull-right">
				<a class="btn btn-danger" href="login.php">Login</a>
			</div>
			</header>
		</div>
		
    
