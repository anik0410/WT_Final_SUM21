    <footer>
      <h4>Group 4 Project</h4>
    </footer>
  </body>
</html>
