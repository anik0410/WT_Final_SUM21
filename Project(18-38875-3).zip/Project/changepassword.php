<?php include 'pwheader.php';
      include 'controllers/usercontroller.php';

      $uname = $_SESSION["uname"];
      $profile = getUserWithUsername($uname);
?>

<html>
  <head>
      <title>Change Password</title>
  </head>
  <body>
      <div align="center" class="add_ad">
      <h1>Change Password</h1>
      <h5><?php echo $err_db;?></h5>
      <form action="" method="post">
          <table>
            
              <tr>
                  <td align="right">Name:</td>
                  <td><input type="text" name="name" value="<?php echo $profile["name"];?>">
                  <span><?php echo $err_name;?><span></td>
              </tr>
              <tr>
                  <td align="right">Username:</td>
                  <td><input type="text" name="uname" value="<?php echo $profile["uname"];?>">
                  <span><?php echo $err_uname;?></span></td>
              </tr>
              <tr>
                  <td align="right">Password:</td>
                  <td><input type="password" name="pass" value="<?php echo $profile["pass"];?>">
                  <span><?php echo $err_pass;?></span></td>
              </tr>
              
              
              <tr>
		        <td align="right"></td>
		        <td><input type="hidden" name="id" value="<?php echo $profile["id"];?>"></td>
             </tr>
              <tr>
                  <td align="right"></td>
                  <td><input type="submit" name="change" value="Change"></td>
              </tr>
          </table>
      </form>

      </div>
  </body>
</html>

<center><?php include 'userfooter.php';?></center>
