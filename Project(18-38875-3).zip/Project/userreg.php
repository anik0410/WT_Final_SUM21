<?php include 'controllers/usercontroller.php';
      include 'main_header.php';
      
?>

<html>
  <head>
      <title>User Registration</title>
  </head>
  <body>
  <div class="body_1">
  <center>
      <h1>User Registration</h1>
      <h5><?php echo $err_db;?></h5>
      <form action="" method="post">
          <table>
              <tr>
                  <td align="right">Name:</td>
                  <td><input type="text" name="name" value="<?php echo $name;?>">
                  <span><?php echo $err_name;?><span></td>
              </tr>
              <tr>
                  <td align="right">Username:</td>
                  <td><input type="text" name="uname" value="<?php echo $uname;?>">
                  <span><?php echo $err_uname;?></span></td>
              </tr>
              <tr>
                  <td align="right">Password:</td>
                  <td><input type="password" name="pass" value="<?php echo $pass;?>">
                  <span><?php echo $err_pass;?></span></td>
              </tr>
			  <tr>
                  <td align="right"></td>
                  <td><input type="submit" class="btn-link3" name="register" value="Register"></td>
              </tr>
          </table>
      </form>
	  </center>
	  </div>
  </body>
</html>
<?php include 'main_footer.php';?>