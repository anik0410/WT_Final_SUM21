<head>
		<link rel="stylesheet" href="styles1/mystyle.css">
	</head>
	<body>
 <header  class="header">
    <div class="header-index">
			<a class="btn"><b class="text-white name">Change password </b></a>
			
			</header>
		</div>