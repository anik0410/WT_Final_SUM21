<?php include_once 'userheader.php';


if(!isset($_SESSION["uname"])){
   header("Location: login.php");
  }
  ?>
<html>
<head>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
  border-right:1px solid #bbb;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
</style>
<title>Menu</title>
</head>
  <body>
  <div class="body_2">
 
  <ul>
     <li> <a href="rate.php">Rate</a></li>
     <li> <a href="Review.php">Review</a></li>
	  <li><a href="myadvertisements.php">My Advertisements</a></li>
	  <li> <a href="Addad.php">Create Advertisement</a><li>
	 <li> <a href="faq.php">FAQ</a><li>
	 <li> <a href="searchad.php">Search </a><li>
	 <li> <a href="login.php">Log Out</a><li>
	 <li> <a href="changepassword.php">Change Password</a></li>
	 </ul>
	 </div>
	    </body>
</html>
<?php include_once 'main_footer.php'; ?>