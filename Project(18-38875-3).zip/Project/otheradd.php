<?php
     require_once 'controllers/addcontroller.php';
	 $Add = getAllAdd();
?>
<div class = "center">
          <h3 class="text">Available Properties</h3>
		  