<?php session_start (); ?>
<head>
		<link rel="stylesheet" href="styles1/mystyle.css">
	</head>
	<body>
 <header  class="header">
    <div class="header-index">
			<a class="btn"><b class="text-white name">WELCOME <?php echo $_SESSION["uname"]; ?> </b></a>
			
			</header>
		</div>