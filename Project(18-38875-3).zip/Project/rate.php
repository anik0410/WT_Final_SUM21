<?php 

   include 'userheader.php';
   require_once 'controllers/ratecontroller.php';
   if(!isset($_SESSION["uname"])){
    header("Location: login.php");
  }
?>
<html>
<head>
      <title>Rate</title>
  </head>
   <body>
  <div class="body_1">
      <center>
<div class="center-login">
  <h1 class="text text-center">Rate Customers </h1> 
  <h5 class="text-danger"><?php echo $err_db; ?></h5>  
  <form action="" onsubmit="return validate()" method="post" class="form-horizontal form-material">
  <div class="form-group">
     <h4 class="text">Name</h4>
	 <input type="text" name="name" value="<?php echo $h_name; ?>" class="form-control">
	 <span class="text-danger"><?php echo $err_name; ?></span>
  </div>   
  <div class="form-group">
     <h4 class="text">User Id</h4>
	 <input type="text" name="Userid" value="<?php echo $p_id; ?>" class="form-control">
	 <span class="text-danger"><?php echo $err_h_id; ?></span>
  </div>
  <div>
                <h4 class="text">Rating:<h4>
				      	<select name="h_rate" value="<?php echo $h_rate;?>">
					      <option disabled selected>rating</option>
						    <?php
							     for($i=1;$i<=10;$i++){
								   echo "<option>$i</option>";
							     }
						    ?>
              </select>
			  <span class="text-danger"><?php echo $err_h_rating; ?></span>

			  </div>
  <div class="form-group">
     <input type="submit" name="submit" value="Submit" class="btn btn-control" class="form-control">
  </div>
  <div class="form-group">
     <input type="submit" name="home" value="Home" class="btn btn-control" class="form-control">
  </div>
  </form></tr>
</div>

      </center>
	  </div >
	  </body>
</html>
<?php include 'userfooter.php' ?>   