<?php
  include 'userheader.php';
  include 'controllers/addcontroller.php';
  
  $p_id = $_GET["p_id"];
  $add = deleteAdvertisement($p_id); 
?>

<body>
  
  <div class="add_ad">
  <form action="" method="post">
  <tr>
  <td align="center"></td>
		<td><input type="hidden" name="p_id" value="<?php echo $add["p_id"];?>"></td>
  </tr>
  <tr>
  <h3>Are you sure you want to delete?</h3>
  </tr>
  <tr>
      <td align="center"></td>
      <td><input type="submit" name="delete_add" value="Yes"></td>
  </tr>
</form>
  </div>
</body>
<?php
  include 'userfooter.php';

  
?>