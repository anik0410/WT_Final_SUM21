
<div class="form-group">
     <a href="login.php" ><input type="submit" name="logout" value="Logout" class="btn btn-control" class="form-control"></a>
</div>