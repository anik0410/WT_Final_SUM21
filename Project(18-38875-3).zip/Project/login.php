
<?php
include 'main_header.php'; 
include 'controllers/usercontroller.php';
?>


<html>
  <head>
      <title>Log In</title>
  </head>
  <body>
  <div class="body_1">
      <center>
      <h1>Log In to rate, review, post any faq and view other adds</h1>
      <h5><?php echo $err_db;?></h5>
      <form action="" method="post">
          <table>
              <tr>
                  <td align="center">Username:</td>
                  <td><input type="text" name="uname" value="<?php echo $uname;?>">
                  <span><?php echo $err_uname;?></span></td>
              </tr>
              <tr>
                  <td align="center">Password:</td>
                  <td><input type="password" name="pass" value="<?php echo $pass;?>">
                  <span><?php echo $err_pass;?></span></td>
              </tr>
              <tr>
                  <td align="center"></td>
                  <td><input type="submit" class="btn-link3" name="login" value="Log in"></td>
              </tr>
              <tr>
                  <td align="center"></td>
                  <td><a href="userreg.php">Not registered yet? Register</a></td>
              </tr>
          </table>
      </form>
	  </center>
      </div>
  </body>
</html>
<?php
include 'main_footer.php'; 
?>
