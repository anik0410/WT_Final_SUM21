<?php include 'userheader.php' ;?>
<h3>Properties Available</h3>
<div class="body_1">
<table border ="2">
  <thead>
      <th>Property Type</th>
      <th>Property Location</th>
      <th>Property Price</th>
      <th>Householder</th>
      <th></th>
      <th></th>
	  <th></th>
  </thead>
  <tbody>

<?php

require_once 'controllers/addcontroller.php';
$Advertisement = getAdvertisements();

        foreach($Advertisement as $a){
          $p_id = $a["p_id"];
          echo "<tr>";
            echo "<td>".$a["p_type"]."</td>";
            echo "<td>".$a["p_location"]."</td>";
            echo "<td>".$a["p_price"]."</td>";
            echo "<td>".$a["id"]."</td>";
            echo '<td><a href="editadvertisement.php?p_id='.$a["p_id"].'">Edit</a></td>';
            echo '<td><a href="deleteadd.php?p_id='.$a["p_id"].'">Delete</a></td>';
			echo '<td><a href="menu.php">Back</a></td>';
          echo "</tr>";
        }
      ?>
	  
	  </tbody>
</table>
</div>
<?php include 'userfooter.php'; ?>