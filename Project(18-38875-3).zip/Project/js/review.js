var hasError = false;
function get(id){
  return document.getElementById(id);
}
function validate(){
	refresh();
	if(get("h_name").value == ""){
    hasError = true;
    get("err_name").innerHTML = " *Name Req";
  }
  if(get("p_id").value == ""){
    hasError = true;
    get("err_p_id").innerHTML = " *Username Req";
  }
  if(get("review").value == ""){
    hasError = true;
    get("err_review").innerHTML = " *Username Req";
  }
  return !hasError;
}
function refresh(){
  get("err_h_name").innerHTML = "";
  get("err_p_id").innerHTML = "";
  get("err_review").innerHTML = "";
 
}