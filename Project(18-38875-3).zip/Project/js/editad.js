var hasError = false;
function get(id){
  return document.getElementById(id);
}
function validate(){
    refresh();
    if(get("p_type").value == ""){
        hasError = true;
        get("err_p_type").innerHTML = " *Type Req";
    }
    if(get("p_location").value == ""){
        hasError = true;
        get("err_p_location").innerHTML = " *Location Req";
    }
    if(get("p_price").value == ""){
        hasError = true;
        get("err_p_price").innerHTML = " *Price Req";
    }
   
    return !hasError;

}
function refresh(){
    hasError = false;
    get("err_p_type").innerHTML = "";
    get("err_p_location").innerHTML = "";
    get("err_p_price").innerHTML = "";

}