var hasError = false;
function get(id){
  return document.getElementById(id);
}
function validate(){
    refresh();
    if(get("h_name").selectedIndex == 0){
        hasError = true;
        get("err_name").innerHTML = " *name Req";
    }
    if(get("h_id").value == ""){
        hasError = true;
        get("err_h_id").innerHTML = " *id Req";
    }
    if(get("faq").value == ""){
        hasError = true;
        get("err_faq").innerHTML = " *faq Req";
    }

    return !hasError;
}
function refresh(){
    hasError = false;
    get("err_name").innerHTML = "";
    get("err_h_id").innerHTML = "";
    get("err_faq").innerHTML = "";

}