<?php 
  include 'controllers/addcontroller.php';
  include 'userheader.php';
  if(!isset($_COOKIE["uname"])){
		header("Location: login.php");
	}
  
  
?>


<body>
  <div align=center class="add_ad">
  <form action="" method="post"><br>

<tr>
    <td align="right"></td>
    <td><input type="text" name="p_location" placeholder="Search..."></td><br>
</tr>
<tr>
    <td align="center"></td><br>
    <td><input type="submit" name="search" value="Search Advertisement"></td>
</tr>
</form>
  </div>
</body>


<center><?php include 'userfooter.php';?></center>