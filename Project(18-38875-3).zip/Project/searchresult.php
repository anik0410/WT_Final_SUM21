<?php include 'userheader.php';
  include 'controllers/addcontroller.php';
 
  $uname = $_SESSION["uname"];
  $add =  getUserWithUsername($uname);

  
  $p_location = $_GET["p_location"];
  $search = searchAdvertisementLocation($p_location);

  

 
  
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Dashboard</title>
  </head>
  <style>
table, td, th {
  border: 2px solid black;
}

table {
  width: 100%;
  border-collapse: collapse;
}
</style>
<html>
  <head>
    <title>Search Result</title>
  </head>
  <body>
    <div align="center" class="add_ad">
    <h3>My Advertisements</h3>
<script src="js/search_ajax.js"></script>
<table>
  <thead>
      <th>Advertisement Type</th>
      <th>Property Location</th>
      <th>Property Price</th>
      <th>User</th>
      
  </thead>
  <tbody>
      <?php
      $search = searchAdvertisementLocation($p_location);
        foreach($search as $a){
          $p_id = $a["p_id"];
          echo "<tr>";
            echo "<td>".$a["p_type"]."</td>";
            echo "<td>".$a["p_location"]."</td>";
            echo "<td>".$a["p_price"]."</td>";
            echo "<td>".$a["id"]."</td>";
          echo "</tr>";
        }
      ?>
  </tbody>
</table>

    </div>
  </body>
</html>
<center><?php include 'userfooter.php';?></center>