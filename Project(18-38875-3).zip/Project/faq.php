<?php
   include'userheader.php';
   require_once 'controllers/faqcontroller.php';
  
?>

<body>
<div class="center-login">
  <h1 class="text text-center">Please leave your FAQs here <?php echo $_SESSION["uname"]; ?></h1> 
  <h5 class="text-danger"><?php echo $err_db; ?></h5>  
  <form action=""  onsubmit="return validate()" method="post">
  <div class="form-group">
     <h4 class="text">Name</h4>
	 <input type="text" name="name" value="<?php echo $h_name; ?>" class="form-control">
	 <span class="text-danger"><?php echo $err_name; ?></span>
  </div>   
  <div class="form-group">
     <h4 class="text">HouseHolder Id</h4>
	 <input type="text" name="Userid" value="<?php echo $h_id; ?>" class="form-control">
	 <span class="text-danger"><?php echo $err_h_id; ?></span>
  </div>
  <div class="form-group">
     <h4 class="text">How can we help you?</h4>
	 <textarea name="faq" value="<?php echo $faq; ?>"></textarea>
	 <span class="text-danger"><?php echo $err_faq; ?></span>
  </div>
  <div class="form-group">
     <input type="submit" name="submit" value="Submit" class="btn btn-control" class="form-control">
  </div>
  <div class="form-group">
     <h4 class="text">Reply from admin</h4>
	 <textarea ></textarea>
	 <span class="text-danger"></span>
  </div>
  <div class="form-group">
     <input type="submit" name="home" value="Home" class="btn btn-control" class="form-control">
  </div>
  
  </form>
</div>
</body>
<script src="js/faq.js"></script>
 <?php include 'userfooter.php';?>