<?php
  include 'userheader.php';
  include 'controllers/addcontroller.php';
  //session_start();

  $uname = $_SESSION["uname"];//bujhte hobe
  $prop =  getUserWithUsername($uname);//bujhte hobe
  //var_dump($_SESSION);
  //echo $_SESSION["h_uname"];

  //$properties = getHouseholders();
?>
<html>
<script src="js/Addad.js"></script>
  <head>
    <title>Create Advertisement</title>
  </head>
    <body>
  <div class="add_ad">
  <h5><?php echo $err_db;?></h5>
  <form action="" onsubmit="return validate()" method="post" enctype="multipart/form-data">
    <center>
      <br><h1>Create Advertisement<h1>
    <table>
       <tr>
            <td align="center">Advertise property for:</td>
            <td>
            <select id="p_type" name="p_type">
              <option selected disabled value="">Choose</option>
              <option value="Selling">Selling</option>
              <option value="Renting">Renting</option>
            </select><span class="id" id="err_p_type"><?php echo $err_p_type;?></span>
            </td>
      </tr>
        <tr>
          <td align="center">Property Location</td>
          <td><input id="p_location" type="text" name="p_location">
        <span class="id" id="err_p_location"><?php echo $err_p_location?></span></td>
        </tr>
        <tr>
          <td align="center">Property Price</td>
          <td><input id="p_price" type="text" name="p_price">
        <span class="id" id="err_p_price"><?php echo $err_p_price;?></span></td>
        </tr>
        <tr>
          <td align="center">Image</td>
          <td><input id="p_img" type="file" name="p_img">
          <span class="id" id="err_p_img"><?php echo $err_p_img;?></span></td> 
        </tr>
        <tr>
		  <td align="center"></td>
		  <td><input type="hidden" name="id" value="<?php echo $prop["id"];?>"></td>

		</tr>
        <tr>
           <td align="center"></td>
           <td><input type="submit" name="add_ad" value="Add Advertisement"></td>
        </tr>

    </table>
    </center>
  </form>
  </div>
</body>
</html>











<center><?php include 'userfooter.php'?></center>
